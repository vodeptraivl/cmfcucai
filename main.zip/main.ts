import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule } from '@app/module/app.module';
import { environment } from './environments/environment';
import { LicenseManager } from "ag-grid-enterprise";

if (environment.mode == 'prod') {
	enableProdMode();
}
LicenseManager.setLicenseKey("CompanyName=I.M.LINK VIETNAM CO., LTD,LicensedGroup=MURATEC ID DEPT,LicenseType=MultipleApplications,LicensedConcurrentDeveloperCount=2,LicensedProductionInstancesCount=0,AssetReference=AG-011738,ExpiryDate=11_November_2021_[v2]_MTYzNjU4ODgwMDAwMA==920d5ac8ae9fd206624ba39aa5e8b380");

platformBrowserDynamic().bootstrapModule(AppModule);
